# Pure Package Filetree

```text
delivery-mainline-1.0-clean
├─ README.md
├─ .env.example
├─ package.json
├─ package-lock.json
├─ index.html
├─ vite.config.web.ts
├─ tsconfig.json
├─ tsconfig.node.json
├─ tailwind.config.js
├─ postcss.config.js
├─ .eslintrc.cjs
├─ .gitignore
├─ .npmrc
├─ .nvmrc
├─ LICENSE
├─ patches/
├─ public/
├─ clean-room/
│  └─ spine/
│     └─ modules/
├─ scripts/
│  ├─ dev-runner.mjs
│  ├─ preflight-deploy.mjs
│  ├─ sync-app-config-env.ts
│  ├─ smoke-cowork-session.mjs
│  ├─ bind-ima-skill.ts
│  ├─ bind-blingbling-little-eye.ts
│  ├─ fix-imports.mjs
│  └─ refresh-clean-web-package.mjs
├─ deploy/
│  └─ linux/
│     ├─ uclaw.env.example
│     └─ uclaw.service
├─ server/
├─ src/
├─ SKILLs/
└─ docs/
   ├─ AGENTS.md
   ├─ DEPLOYMENT_STANDARD_LINUX.md
   ├─ MAINLINE_1.0_BOUNDARY.md
   ├─ PURE_PACKAGE_FILETREE.md
   ├─ RUNBOOK_1.0.md
   └─ REPAIR_CHECKLIST_2026-03-25_06-07.md
```
